﻿using System;
using System.Diagnostics;

namespace Algorithms;
public static class Methods
{
    public delegate void SortingDelegate(int[] array);
    public delegate int SearchDelegate(int[] array, int target);
    public static void Swap(int[] numberArray, int index1, int index2)
    {
        int temp = numberArray[index1];
        numberArray[index1] = numberArray[index2];
        numberArray[index2] = temp;
    }

    public static void Randomize(int[] numberArray)
    {
        var arraySize = numberArray.Length;
        for (var i = 0; i < arraySize; i++) {
            numberArray[i] = new Random().Next(0, arraySize * 10);
        }
    }

    public static int[] Prepare(int arraySize)
    {
        int[] numberArray = new int[arraySize];
        Randomize(numberArray);
        return numberArray;
    }

    public static void InsertionSort(int[] numberArray)
    {
        for (int index = 1; index < numberArray.Length; index++)
        {
            int key = numberArray[index];
            int j = index - 1;
            while (j >= 0 && numberArray[j] > key)
            {
                numberArray[j + 1] = numberArray[j];
                j--;
            }
            numberArray[j + 1] = key;
        }
    }

    public static void SelectionSort(int[] array)
    {
        for (int i = 0; i < array.Length - 1; i++)
        {
            int minIndex = i;
            for (int j = i + 1; j < array.Length; j++)
            {
                if (array[j] < array[minIndex])
                    minIndex = j;
            }
            Swap(array, i, minIndex);
        }
    }

    public static void BubbleSort(int[] array)
    {
        for (int i = 0; i < array.Length - 1; i++)
        {
            for (int j = 0; j < array.Length - i - 1; j++)
            {
                if (array[j] > array[j + 1])
                    Swap(array, j, j + 1);
            }
        }
    }

    public static void MergeSort(int[] array)
    {
        MergeSort(array, 0, array.Length - 1);
    }

    private static void MergeSort(int[] array, int left, int right)
    {
        if (left < right)
        {
            int mid = (left + right) / 2;
            MergeSort(array, left, mid);
            MergeSort(array, mid + 1, right);
            Merge(array, left, mid, right);
        }
    }

    private static void Merge(int[] array, int left, int mid, int right)
    {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        int[] leftArray = new int[n1];
        int[] rightArray = new int[n2];

        Array.Copy(array, left, leftArray, 0, n1);
        Array.Copy(array, mid + 1, rightArray, 0, n2);

        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2)
        {
            if (leftArray[i] <= rightArray[j])
                array[k++] = leftArray[i++];
            else
                array[k++] = rightArray[j++];
        }

        while (i < n1) array[k++] = leftArray[i++];
        while (j < n2) array[k++] = rightArray[j++];
    }

    public static void QuickSort(int[] array)
    {
        QuickSort(array, 0, array.Length - 1);
    }

    private static void QuickSort(int[] array, int low, int high)
    {
        if (low < high)
        {
            int pi = Partition(array, low, high);
            QuickSort(array, low, pi - 1);
            QuickSort(array, pi + 1, high);
        }
    }

    private static int Partition(int[] array, int low, int high)
    {
        int pivot = array[high];
        int i = low - 1;

        for (int j = low; j < high; j++)
        {
            if (array[j] < pivot)
            {
                i++;
                Swap(array, i, j);
            }
        }
        Swap(array, i + 1, high);
        return i + 1;
    }

    public static void SortByLambda(int[] array) 
    {
        array.OrderBy(x => x).ToArray();
    }


    public static int LinearSearch(int[] array, int target)
    {
        for (int i = 0; i < array.Length; i++)
        {
            if (array[i] == target)
            {
                return i; // Return the index if the target is found
            }
        }
        return -1; // Return -1 if the target is not found
    }

    public static int BinarySearch(int[] array, int target)
    {
        int left = 0, right = array.Length - 1;

        while (left <= right)
        {
            int mid = left + (right - left) / 2;

            if (array[mid] == target)
            {
                return mid; // Return the index in the sorted array
            }

            if (array[mid] < target)
            {
                left = mid + 1;
            }
            else
            {
                right = mid - 1;
            }
        }

        return -1; // Target not found
    }


    public static int SearchByLambda(int[] array, int target)
    {
        return Array.FindIndex(array, x => x == target);

    }

    public static double DisplayRunningTime(int[] array, SortingDelegate sortingDelegate)
    {
        var stopwatch = Stopwatch.StartNew();

         sortingDelegate(array);
        stopwatch.Stop();

        return stopwatch.Elapsed.TotalMilliseconds;
    }

    public static (double elapsedTime, int position) DisplayRunningTime(int[] array, int target, SearchDelegate searchDelegate)
    {
        var stopwatch = Stopwatch.StartNew();

        // Invoke the search delegate
        var index = searchDelegate(array, target);

        stopwatch.Stop();
        return (stopwatch.Elapsed.TotalMilliseconds, index);
    }
}
